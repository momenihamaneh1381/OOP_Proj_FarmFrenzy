package classes;
public enum FactoryType {
    BASIC,
    COMPLICATED
}
