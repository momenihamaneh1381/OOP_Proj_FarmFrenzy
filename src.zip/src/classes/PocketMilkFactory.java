package classes;
public class PocketMilkFactory extends Factory{
    public PocketMilkFactory() {
        super(400, 6, FactoryType.BASIC , ProductType.MILK , ProductType.POCKET_MILK , FactoryName.POCKET_MILK_FACTORY);
    }
}
