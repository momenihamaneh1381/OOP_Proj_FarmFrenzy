package classes;
public class Wing extends Product{
    public Wing(int x ,int y) {
        super(ProductType.WING ,x ,y);
    }
}
