package classes;

import javafx.scene.layout.Pane;

public class Lion extends WildAnimal {

    public Lion(Pane parent) {
        super(3, 1,300 , AnimalType.LION , parent);
    }
}
