package classes;
public class Egg extends Product{
    public Egg(int x ,int y) {
        super(ProductType.EGG ,x ,y);
    }
}
