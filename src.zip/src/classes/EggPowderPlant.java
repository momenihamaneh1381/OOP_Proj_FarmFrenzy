package classes;
public class EggPowderPlant extends Factory{
    public EggPowderPlant() {
        super(150 , 4,FactoryType.BASIC , ProductType.EGG , ProductType.POWDER , FactoryName.EGG_POWDER_PLANT);
    }
}
