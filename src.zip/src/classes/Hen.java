package classes;

import javafx.scene.layout.Pane;

public class Hen extends DomesticAnimal {


    public Hen(Pane parent) {
        super(100, 2 , ProductType.EGG , AnimalType.HEN ,parent);
    }
}
