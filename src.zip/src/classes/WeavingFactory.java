package classes;
public class WeavingFactory extends Factory{
    public WeavingFactory() {
        super(250,5,FactoryType.BASIC , ProductType.WING , ProductType.FABRIC , FactoryName.WEAVING_FACTORY);
    }
}
