package classes;
public class Bakery extends Factory{
    public Bakery() {
        super(250 , 5 ,FactoryType.COMPLICATED , ProductType.POWDER, ProductType.BREAD ,FactoryName.BAKERY);
    }
}
