package classes;

import javafx.scene.layout.Pane;

public class Turkey extends DomesticAnimal{
    public Turkey(Pane parent) {
        super(200,3 , ProductType.WING , AnimalType.TURKEY , parent);
    }
}
