package classes;
public enum AnimalType {
    HEN ,
    TURKEY ,
    BUFFALO ,
    CAT ,
    HOUND ,
    TIGER ,
    LION ,
    BEAR
}
