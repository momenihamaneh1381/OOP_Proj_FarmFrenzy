package classes;
public interface Turn {
    public void turn();
}
