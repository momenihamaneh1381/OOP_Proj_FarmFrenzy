package classes;


public class Main {
    public static void main(String[] args) {
        String []s ={"tiger" , "lion"};
        int []n = {2 , 15};
        Step step = new Step("powder" ,2  , "turkey", 2 , s ,n ,
                1000 , 200 , 40 , 0 );

    }

}
