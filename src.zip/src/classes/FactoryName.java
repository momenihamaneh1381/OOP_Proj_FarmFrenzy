package classes;
public enum FactoryName {
    BAKERY ,
    EGG_POWDER_PLANT ,
    ICECREAM_FACTORY,
    POCKET_MILK_FACTORY,
    SEWING_FACTORY,
    WEAVING_FACTORY,
    INCUBATOR
}
