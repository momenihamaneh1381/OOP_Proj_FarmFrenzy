package classes;
public class SewingFactory extends Factory{
    public SewingFactory() {
        super(400, 6, FactoryType.COMPLICATED, ProductType.FABRIC, ProductType.CLOTH , FactoryName.SEWING_FACTORY);
    }
}
