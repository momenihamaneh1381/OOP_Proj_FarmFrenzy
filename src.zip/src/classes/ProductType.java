package classes;
public enum ProductType {
    EGG,
    MILK,
    WING,
    POWDER,
    FABRIC,
    POCKET_MILK,
    BREAD,
    CLOTH,
    ICE_CREAM,
    HEN
}
