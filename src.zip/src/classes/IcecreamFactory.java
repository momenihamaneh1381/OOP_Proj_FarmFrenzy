package classes;
public class IcecreamFactory extends Factory{
    public IcecreamFactory() {
        super(550, 7, FactoryType.COMPLICATED, ProductType.POCKET_MILK, ProductType.ICE_CREAM , FactoryName.ICECREAM_FACTORY);
    }
}
