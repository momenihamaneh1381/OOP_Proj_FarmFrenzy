package classes;

import javafx.scene.layout.Pane;

public class Tiger extends WildAnimal{
    public Tiger(Pane parent) {
        super(4, 2,500 , AnimalType.TIGER , parent);
    }
}
