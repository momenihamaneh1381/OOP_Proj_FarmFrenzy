package classes;
public class Milk extends Product{

    public Milk( int x, int y) {
        super(ProductType.MILK, x, y);
    }
}
